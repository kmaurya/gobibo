package test.factory.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestFactPages {

	HtmlReport  report;
	WebDriver driver;
	Document document;
	
	public TestFactPages(WebDriver driver) throws DocumentException, FileNotFoundException {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
		File src = new File("./DataInputs/TestPath.xml");
		System.out.println("Hello");
		FileInputStream fis1 = new FileInputStream(src);
		SAXReader saxReader = new SAXReader();
		document = saxReader.read(fis1);
	}

	public void sendData(String path,String addPath,String addVal) throws InterruptedException, IOException
	{
		driver.findElement(By.xpath(getXpath(path,addPath))).sendKeys(getXpath(path,addVal));
		Thread.sleep(1000);	
		//report.generateReport();
	}
	
	public void sendData1(String path,String addPath) throws InterruptedException, IOException
	{
		driver.findElement(By.xpath(getXpath(path,addPath))).sendKeys(" ");
		Thread.sleep(1000);	
		//report.generateReport();
	}
	
	public String getXpath(String path,String add)
	{
		String xPath=document.selectSingleNode(path+add).getText();
		return xPath;
	}
	// Method for Sending data into textfield

	// Method for Clicking buttons
	public void clickButton(String path,String add) {
		try{driver.findElement(By.xpath(getXpath(path,add))).click();}
		catch(Exception e)
		{
			e.printStackTrace();
			e.getMessage();
		}
	}

	// Method for Checking for Alert Present
	public void alertPresent(String alt) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.alertIsPresent());
		String alrt = driver.switchTo().alert().getText();
		System.out.println(alrt);
	}

	// Method for Checking the Visibility of Fields
	public void isPresent(String path) {
		driver.findElement(By.xpath(path)).isDisplayed();
	}
	
	// Method for Selecting dates from Calender
	public void calDate(String path,String dateSelect,String add) {
		driver.findElement(By.xpath(getXpath(path,dateSelect))).click();
		driver.findElement(By.xpath(getXpath(path,add))).click();		
	}

	public void travellers(String path,String add,int count) {
		for(int i=1;i<count;i++)
		{
		driver.findElement(By.xpath(getXpath(path,add))).click();
		}
	}

	// Method for Selecting Dropdown value for Travellers
	public void selectClass(String path,String add, int index) {
		Select drp=new Select(driver.findElement(By.xpath(getXpath(path,add))));
		drp.selectByIndex(index);
	}

	// Method for clicking Swap Button
	//public void () {

	

}
