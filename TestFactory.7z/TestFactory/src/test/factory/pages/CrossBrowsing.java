package test.factory.pages;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

public class CrossBrowsing {

	String brow_name,bro_type,bro_path;
	Properties pro;
	WebDriver driver;
	
	public WebDriver fileOpenProperty()
	{
		try
		{
			File src = new File("./DataInputs/text.property");
			FileInputStream fis = new FileInputStream(src);
			pro=new Properties();
			pro.load(fis);
			brow_name=pro.getProperty("browser_name");
			brow_name="Firefox";
			switch("Chrome"){
			
					case "Chrome":
						System.setProperty(pro.getProperty("browser_type"), pro.getProperty("browser_path"));
						driver=new ChromeDriver();
						driver.get(pro.getProperty("url"));	
					break;
			
					case "Internet":
						System.setProperty(pro.getProperty("browser_type"), pro.getProperty("browser_path"));
						driver=new InternetExplorerDriver();
						driver.get(pro.getProperty("url"));	
					break;
				
				/*	case "Firefox":
						//System.setProperty(pro.getProperty("browser_type"), pro.getProperty("browser_path"));
						driver=new FirefoxDriver();
						driver.get(pro.getProperty("url"));	
					break;*/
			
					default: 
						System.out.println("No browser found");
					break;
				
			}
			
			}
		  
	
		catch(Exception e)
		{
			e.printStackTrace();
			e.getMessage();		
		}
		return this.driver;
	}
	}

