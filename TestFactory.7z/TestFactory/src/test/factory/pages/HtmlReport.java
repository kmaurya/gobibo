package test.factory.pages;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
public class HtmlReport {
	
	File htmlReader;
	String htmlString,body;
	int a=1;
	
	public static void main(String[] args) {
	
	}
	public void inReport() throws IOException
	{
		try{
		htmlReader = new File("./DataInputs/HtmlReportTemplate.html");
		htmlString=FileUtils.readFileToString(htmlReader);}
		catch(Exception E)
		{
			E.printStackTrace();
			E.getMessage();
		}
	}

	public void generateReportBody() throws IOException
	{	
		
		htmlString=htmlString.replace("$ID", String.valueOf(a));
		htmlString=htmlString.replace("$start_time", LocalDateTime.now().toString());
		htmlString=htmlString.replace("$end_time", LocalDateTime.now().toString());
		htmlString=htmlString.replace("$version", System.getProperty("java.vm.version"));
		htmlString=htmlString.replace("$os_name",System.getProperty("os.name"));
		htmlString=htmlString.replace("$remark", "Pass");
		a++;
	}
	
	public void generateReport() throws IOException
	{
		generateReportBody();
		File htmlReport=new File("./DataInputs/HtmlReport.html");
		FileUtils.writeStringToFile(htmlReport, htmlString);
	}
	
	 public void takeScreenShot(WebDriver driver, String filePath) {
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        try {
	            FileUtils.copyFile(scrFile, new File(filePath));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
}
