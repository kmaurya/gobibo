package test.factory.tests;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

import com.google.gson.annotations.Until;
import com.thoughtworks.selenium.webdriven.commands.WaitForCondition;

import test.factory.pages.CrossBrowsing;
import test.factory.pages.HtmlReport;
import test.factory.pages.TestFactPages;

public class TestFactTest {
	
	WebDriver driver;
	Document document,document1;
	TestFactPages tfp;
	String path="//goibibo/";
	String path1="//goibibo/Travellers/";
	CrossBrowsing cb;
	HtmlReport  report;
	
	@BeforeMethod
	  public void abc() throws Exception {
		System.out.println("Starting Test");   
	     cb=new CrossBrowsing();  
		driver=cb.fileOpenProperty();
		  tfp=new TestFactPages(driver);
		  report=new HtmlReport();
		  report.inReport();
	  }
/*	
  @Test
  public void testPass() throws InterruptedException, IOException {
	  
	  tfp.clickButton(path, "Round");
	  tfp.sendData(path, "FromPath","FromVal");
	  Thread.sleep(1000); 
	 tfp.sendData(path, "DestinationPath","DestinationVal");
	 tfp.calDate(path, "Depart","DepartDate"); 
	 tfp.calDate(path, "Arrival", "DepartDate");
	 tfp.clickButton(path, "Travellers");
	 tfp.travellers(path1, "TravelAdultPlus",2);
	 tfp.travellers(path1, "TravelChildPlus",2);
	 tfp.clickButton(path, "Class");
	 tfp.selectClass(path, "Class", 1);
	 tfp.clickButton(path, "GoButton");
	 report.generateReport();
	 String screenShotPath = System.getProperty("user.dir") + "/HtmlReport/Failure.jpeg";
     // Take screen shot of page
     report.takeScreenShot(driver, screenShotPath);
     tfp.clickButton(path, "RoundBook");
  }
 */
  @Test
  public void testPassInvalid() throws InterruptedException, IOException {
	  tfp.clickButton(path, "Round");
	  tfp.sendData(path, "FromPath","FromVal");
	  Thread.sleep(1000); 
	 tfp.sendData(path, "DestinationPath","DestinationVal");
	 tfp.calDate(path, "Depart","DepartDate"); 
	 tfp.calDate(path, "Arrival", "DepartDate");
	 tfp.clickButton(path, "Travellers");
	 tfp.travellers(path1, "TravelAdultPlus",2);
	 tfp.travellers(path1, "TravelChildPlus",2);
	 tfp.clickButton(path, "Class");
	 tfp.selectClass(path, "Class", 1);
	 tfp.sendData1(path, "FromPath");
	 tfp.clickButton(path, "GoButton");
	 report.generateReport();
	 String screenShotPath = System.getProperty("user.dir") + "/HtmlReport/Failure.jpeg";
     // Take screen shot of page
     report.takeScreenShot(driver, screenShotPath);
     tfp.clickButton(path, "RoundBook");
  }
  /*
  @Test
  public void oneWay() throws Exception {
		tfp.clickButton(path, "OneWay");
		Thread.sleep(1000);
		 tfp.sendData(path, "FromPath","FromVal");
		  Thread.sleep(1000); 
		 tfp.sendData(path, "DestinationPath","DestinationVal");
		 tfp.calDate(path, "Depart","DepartDate"); 
		// tfp.calDate(path, "Arrival", "DepartDate");
		 tfp.clickButton(path, "Travellers");
		 tfp.travellers(path1, "TravelAdultPlus",2);
		 tfp.travellers(path1, "TravelChildPlus",2);
		 tfp.clickButton(path, "Class");
		 tfp.selectClass(path, "Class", 1);
		 tfp.clickButton(path, "GoButton");
		 report.generateReport();
		 String screenShotPath = System.getProperty("user.dir") + "/HtmlReport/Failure.jpeg";
	     // Take screen shot of page
	     report.takeScreenShot(driver, screenShotPath);
	     tfp.clickButton(path, "OneWayBook");
	     
		/* cadb.SendValues(cadb.getValue(document, cadb.getXmlData("from")),cadb.getValue(document, cadb.getXmlPath("from")));
		 Thread.sleep(1000);
		 cadb.SendValues(cadb.getValue(document, cadb.getXmlData("to")),cadb.getValue(document, cadb.getXmlPath("to")));
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("cal")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("depart")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("traveller")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("traveller/adult/plus")).getText());
		 Thread.sleep(1000);
		 
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("traveller/child/plus")).getText());
		 Thread.sleep(1000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("TClass/bu")).getText());
		 Thread.sleep(1000);
		 
		 //cadb.Section(document.selectSingleNode(cadb.getXmlPath("TClass")).getText(),"B");
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("Go")).getText());
		 Thread.sleep(3000);
		 cadb.Click(document.selectSingleNode(cadb.getXmlPath("book")).getText());
		 Thread.sleep(3000);
		 driver.navigate().back();
			Thread.sleep(3000);
			driver.navigate().back();
			Thread.sleep(1000);
		//cadb.ClearVal(document.selectSingleNode(cadb.getXmlData("from")).getText());
			driver.findElement(By.xpath("//*[@id='gosuggest_inputSrc']")).clear();
			Thread.sleep(500);
			 cadb.Click(document.selectSingleNode(cadb.getXmlPath("Go")).getText());
			 Thread.sleep(3000);
		 
			
			 Thread.sleep(1000);

			
		// cadb.SendValues(cadb.getValue(document, cadb.getXmlData("depart")),cadb.getValue(document, cadb.getXmlPath("depart")));
		 //Thread.sleep(1000);
	}
  */
  @AfterMethod
  public void closingAll()
  {

	  //driver.close();
  }
}
